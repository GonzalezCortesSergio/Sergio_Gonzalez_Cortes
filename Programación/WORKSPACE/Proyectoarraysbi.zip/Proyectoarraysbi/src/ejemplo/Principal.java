package ejemplo;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		
		//pregunta 2
		
        System.out.println("Buenos dias, hoy es"+dias[opcion-1]+ "y tenemos un dia muy soleado\t\n"
        		+ "\n"
        		+ "¿Con qué pie empezamos el dia?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Pie izquierdo\t\n"
        		+ "Opción 2: Pie derecho\t\n");
        
        
        System.out.println("Tu probabilidad de morir aumento a un "+porcentaje+ "%, Nunca debes empezar el día con ese pie");
        
        //pregunta 3
        
        System.out.println("Después de vestirnos y prepararnos toca ir a desayunar y tenemos leche y cereales solamente(Vida de estudiante)\t\n"
        		+ "\n"
        		+ "¿Qué se pone primero la leche o los cereales?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: La leche \t\n"
        		+ "Opción 2: Los cereales\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, se ve que no eres muy listo...");
        
        
        //pregunta 4
        
        System.out.println("Uff nos hemos entretenido en el desayuno y vamos tarde a  un compromiso, ¡No podemos dar mala imagen!\t\n"
        		+ "\n"
        		+ "¿Utilizamos la moto?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Si\t\n"
        		+ "Opción 2: No\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, las prisas son malas consejeras, deberías no haber faltado tanto crack");
        
        
        //pregunta 4
        
        
        System.out.println("Después de nuestro compromiso es hora de ir a comer\t\n"
        		+ "\n"
        		+ "¿Qué debería comer?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Un McDonals's \t\n"
        		+ "Opción 2: Taberna Encarni\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, ese colesterol sube como la espuma,deberías cuidar tu alimentación");
      
        //pregunta 5
        
        
        System.out.println("Me he pasado comiendo, estaría bien una siesta pero me gustaría también ir al gimnasio \t\n"
        		+ "\n"
        		+ "¿Que debería hacer?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Ir al gymnsaio, esos biceps no se esculpen solos \t\n"
        		+ "Opción 2: Una buena siesta siempre sienta bien\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, aunque hacer ejercicio esta genial, si te encuentras tan lleno no deberías de hacer deporte, se nota que no fuiste a comer a la playa con tu madre");
        
		
		//pregunta 6
        
        
        System.out.println("Ya son las 7 de la tarde, y de camino a casa olvidas que habias quedado para ver a tu abuela\t\n"
        		+ "\n"
        		+ "¿Vas a visitarla?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Si, llevamos tiempo sin verla\t\n"
        		+ "Opción 2: No, mejor otro día\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, se buen nieto y visita a tu abuela, ya me lo agradeceras");
        
		
        
        //pregunta 7
        
        System.out.println(" De camino a casa he mirado por el grupo de la clase, han quedado para jugar a los bolos\t\n"
        		+ "\n"
        		+ "¿Debería apuntarme al plan?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Si, se ven buena gente\t\n"
        		+ "Opción 2: No, me gusta ir más a mi rollo\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, todos necesitamos socializar de vez en cuando, ¡Sal de tu zona de confort! ");
        
		
		//pregunta 8 
        
        System.out.println("Por fin estamos en casa, pero se me olvido tirar la basura, de camino al contenedor escuchamos un ruido extraño, al parecer alguien pide ayuda a gritos\t\n"
        		+ "\n"
        		+ "¿Debería ayudar?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Si, podría estar en peligro\t\n"
        		+ "Opción 2: No, me voy a meter en problemas\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, se nota que eres buena persona, a veces la peor opción para uno mismo es la correcta ");
        
		
       //pregunta 9 
        
        
        
        System.out.println("Es hora de tomarte una ducha antes de ir a dormir, eres programador, la gente te lo tendrá en consideración\t\n"
        		+ "\n"
        		+ "¿Utilizamos Jabón de cuerpo o un gel?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Jabón de cuerpo, me gusta el de lavanda que me regalo mi abuela\t\n"
        		+ "Opción 2: Gel, me compre uno de vainilla que huele de muerte\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, todos sabemos que las pastillas de jabón son peligrosas, espero que nunca vayas a la cárcel");
        
		
        

		//pregunta 10
        
                System.out.println("Estabas a punto de dormirte, suena el telefonó es tu mejor amigo Jordan, te dice que a las 3 de la mañana van a ir a una discoteca en el polígono calongue, el ambiente es algo raro ya que va a ir bad bunny como artista invitado \t\n"
        		+ "\n"
        		+ "¿Debería ir a la fiesta ?\t\n"
        		+ "-------------------------------------\t\n"
        		+ "Opción 1: Ir a ver a Bad bunny\t\n"
        		+ "Opción 2: Quedarse en casa descansando\t\n");
        
        System.out.println("Tu probailidad de morir a aumentado en un "+porcentaje+"%, es peligroso ir a sitios tan concurridos y con poca seguridad, además te vas a levantar con una resaca de tres pares. Espero que haya valido la pena el concierto.  ");
        
		
		
	}

}
